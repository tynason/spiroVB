﻿Imports System
Imports System.IO

Public Class spiro

    Private ht As Int16

    Private Sub spiro_Load(sender As Object, e As EventArgs) Handles Me.Load

        Static done As Boolean = False
        If Not done Then

            ht = 1400

            Timer1.Interval = 3000
            Timer1.Enabled = True

            Me.Text = "spiro"
            Me.Width = 1100
            Me.Height = ht
            Me.BackColor = Color.Black

            pic1.Size = New Size(700, 700)
            pic1.Left = 0
            pic1.Top = 25
            pic1.BackColor = Color.Black
            pic1.BorderStyle = BorderStyle.None

            pic2.Left = 950
            pic2.Top = 25
            pic2.BackColor = Color.DimGray
            pic2.BorderStyle = BorderStyle.None
            pic2.Height = 32
            pic2.Width = 100

            rtb1.Left = 730
            rtb1.Top = 65
            rtb1.Height = ht
            rtb1.Width = 200
            rtb1.BackColor = Color.Black
            rtb1.ForeColor = Color.Turquoise
            rtb1.ScrollBars = RichTextBoxScrollBars.None
            rtb1.BorderStyle = BorderStyle.None

            rtb2.Left = 950
            rtb2.Top = 65
            rtb2.Height = ht
            rtb2.Width = 100
            rtb2.BackColor = Color.Black
            rtb2.ForeColor = Color.Turquoise
            rtb2.ScrollBars = RichTextBoxScrollBars.None
            rtb2.BorderStyle = BorderStyle.None

            rtb3.Left = 730
            rtb3.Top = 10
            rtb3.Height = 40
            rtb3.Width = 160
            rtb3.BackColor = Color.Black
            rtb3.ForeColor = Color.Lime
            rtb3.ScrollBars = RichTextBoxScrollBars.None
            rtb3.BorderStyle = BorderStyle.None

            done = True
        End If

    End Sub

    Public Sub Plot()

        ' this generates points which are added to array Data(Points) to be passed to calc/plotting routines
        Dim t As Integer
        Dim tmin As Integer = 1
        Dim tmax As Integer = 300
        Dim intertimer As Int32 = 100

        Dim Rbig As Double
        Dim Rsmall As Double
        Dim O As Double

        Dim xmin As Single = 100000000
        Dim xmax As Single = -100000000
        Dim ymin As Single = 100000000
        Dim ymax As Single = -100000000

        Dim delx As Single = 0
        Dim dely As Single = 0


        ' call out the data array
        ' should dynamically redim these per tmax
        Dim x(810) As Single, y(810) As Single

        Randomize()
        Rbig = 100 * Rnd()
        Rsmall = 100 * Rnd()
        O = 100 * Rnd()

        ' x(0) = 0 ' initial point
        ' y(0) = 0
        x(0) = (Rbig + Rsmall) * Math.Cos(0) - (Rsmall + O) * Math.Cos(((Rbig + Rsmall) / Rsmall) * 0)
        y(0) = (Rbig + Rsmall) * Math.Sin(0) - (Rsmall + O) * Math.Sin(((Rbig + Rsmall) / Rsmall) * 0)

        For t = tmin To tmax
            x(t) = (Rbig + Rsmall) * Math.Cos(t) - (Rsmall + O) * Math.Cos(((Rbig + Rsmall) / Rsmall) * t)
            y(t) = (Rbig + Rsmall) * Math.Sin(t) - (Rsmall + O) * Math.Sin(((Rbig + Rsmall) / Rsmall) * t)
            If x(t) > xmax Then xmax = x(t)
            If x(t) < xmin Then xmin = x(t)
            If y(t) > ymax Then ymax = y(t)
            If y(t) < ymin Then ymin = y(t)
        Next

        ' print params
        rtb3.Clear()
        rtb3.Text += "Rbig " & Rbig & vbCrLf
        rtb3.Text += "Rsm " & Rsmall & vbCrLf
        rtb3.Text += "O " & O & vbCrLf

        ' print data
        rtb1.Clear()
        rtb1.Text += "dataxx datayy" & vbCrLf
        For t = tmin To tmax
            rtb1.Text += x(t) & vbTab & y(t) & vbCrLf
        Next

        ' plot data
        Dim b111 As New Bitmap(pic1.Width, pic1.Height)
        Dim g111 As Graphics = Graphics.FromImage(b111)
        Dim Pen1 As New Pen(Color.Turquoise, 1)
        Pen1.Color = GetColor()

        ' call out the pixels array
        Dim pixx(810) As Single, pixy(810) As Single

        Dim oldx As Single
        Dim oldy As Single

        delx = (xmax - xmin) / pic1.Width
        dely = (ymax - ymin) / pic1.Height
        If delx <= 0 Or dely <= 0 Then Exit Sub

        ' rtb1.Text += vbCrLf & "DELX DELY" & vbCrLf
        ' rtb1.Text += delx & vbTab & dely & vbCrLf

        pixx(0) = (x(0) - xmin) / delx
        pixy(0) = (y(0) - ymin) / dely
        oldx = x(tmin)
        oldy = y(tmin)

        For t = tmin To tmax
            pixx(t) = (x(t) - xmin) / delx
            pixy(t) = (y(t) - ymin) / dely
        Next

        ' print pixels
        rtb2.Clear()
        rtb2.Text += "pixx pixy" & vbCrLf
        For t = tmin To tmax
            rtb2.Text += pixx(t) & vbTab & pixy(t) & vbCrLf
        Next

        For t = tmin To tmax
            g111.DrawLine(Pen1, pixx(t), pixy(t), oldx, oldy)
            pic1.Image = b111
            oldx = pixx(t)
            oldy = pixy(t)
            ' Threading.Thread.Sleep(5)
            ' Thread.Sleep(intertimer)
        Next

    End Sub

    Private Function GetColor()
        Dim m_Rnd As New Random
        Return Color.FromArgb(255, m_Rnd.Next(0, 220), m_Rnd.Next(60, 190), m_Rnd.Next(90, 140))
        'Return Color.FromArgb(255, m_Rnd.Next(0, 20), m_Rnd.Next(240, 255), m_Rnd.Next(90, 140))
    End Function

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Plot()
    End Sub

    Private Sub pic1_Click(sender As Object, e As EventArgs) Handles pic1.Click
        ' https://msdn.microsoft.com/en-us/library/hxwfzt61.aspx
        ' https://msdn.microsoft.com/en-us/library/system.io.directory.getcurrentdirectory(v=vs.110).aspx?cs-save-lang=1&cs-lang=vb#code-snippet-1
        ' http://www.homeandlearn.co.uk/NET/nets8p4.html

        Try
            Dim path As String
            path = My.Computer.FileSystem.CurrentDirectory
            Dim filename As String
            filename = path + "\test.txt"

            Dim file As System.IO.StreamWriter
            Dim data As String
            data = rtb3.Text + vbCrLf

            file = My.Computer.FileSystem.OpenTextFileWriter(filename, True)
            file.WriteLine(data)
            file.Close()

            ' MsgBox(My.Computer.FileSystem.CurrentDirectory)
            ' End
        Catch ex As Exception
            MessageBox.Show("Error writing to text file.")
        End Try


        ' If System.IO.File.Exists(FILE_NAME) = True Then
        ' Dim objWriter As New System.IO.StreamWriter(filename)
        ' objWriter.Write(TextBox1.Text)
        ' objWriter.Close()
        ' MessageBox.Show("Text written to file")
        ' Else
        ' MessageBox.Show("File Does Not Exist")
        ' End If


    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        End

    End Sub




    ' rtb1.Text += vbCrLf & "xmin xmax ymin ymax" & vbCrLf
    ' rtb1.Text += xmin & vbTab & xmax & vbTab & ymin & vbTab & ymax & vbCrLf
End Class