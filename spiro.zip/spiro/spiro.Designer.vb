﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class spiro
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pic1 = New System.Windows.Forms.PictureBox()
        Me.rtb1 = New System.Windows.Forms.RichTextBox()
        Me.rtb2 = New System.Windows.Forms.RichTextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.rtb3 = New System.Windows.Forms.RichTextBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.pic2 = New System.Windows.Forms.PictureBox()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic1
        '
        Me.pic1.BackColor = System.Drawing.Color.Black
        Me.pic1.Location = New System.Drawing.Point(16, 15)
        Me.pic1.Margin = New System.Windows.Forms.Padding(4)
        Me.pic1.Name = "pic1"
        Me.pic1.Size = New System.Drawing.Size(436, 439)
        Me.pic1.TabIndex = 0
        Me.pic1.TabStop = False
        '
        'rtb1
        '
        Me.rtb1.BackColor = System.Drawing.Color.Black
        Me.rtb1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb1.ForeColor = System.Drawing.Color.Lime
        Me.rtb1.Location = New System.Drawing.Point(460, 75)
        Me.rtb1.Margin = New System.Windows.Forms.Padding(4)
        Me.rtb1.Name = "rtb1"
        Me.rtb1.Size = New System.Drawing.Size(133, 379)
        Me.rtb1.TabIndex = 2
        Me.rtb1.Text = ""
        '
        'rtb2
        '
        Me.rtb2.BackColor = System.Drawing.Color.Black
        Me.rtb2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb2.ForeColor = System.Drawing.Color.Lime
        Me.rtb2.Location = New System.Drawing.Point(601, 75)
        Me.rtb2.Margin = New System.Windows.Forms.Padding(4)
        Me.rtb2.Name = "rtb2"
        Me.rtb2.Size = New System.Drawing.Size(133, 379)
        Me.rtb2.TabIndex = 3
        Me.rtb2.Text = ""
        '
        'Timer1
        '
        '
        'rtb3
        '
        Me.rtb3.BackColor = System.Drawing.Color.Black
        Me.rtb3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb3.ForeColor = System.Drawing.Color.Lime
        Me.rtb3.Location = New System.Drawing.Point(460, 15)
        Me.rtb3.Margin = New System.Windows.Forms.Padding(4)
        Me.rtb3.Name = "rtb3"
        Me.rtb3.Size = New System.Drawing.Size(178, 53)
        Me.rtb3.TabIndex = 1
        Me.rtb3.Text = ""
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(109, 30)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(108, 26)
        Me.ExitToolStripMenuItem.Text = "exit"
        '
        'pic2
        '
        Me.pic2.BackColor = System.Drawing.Color.Black
        Me.pic2.Location = New System.Drawing.Point(690, 18)
        Me.pic2.Name = "pic2"
        Me.pic2.Size = New System.Drawing.Size(44, 50)
        Me.pic2.TabIndex = 4
        Me.pic2.TabStop = False
        '
        'spiro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(776, 539)
        Me.Controls.Add(Me.pic2)
        Me.Controls.Add(Me.rtb3)
        Me.Controls.Add(Me.rtb2)
        Me.Controls.Add(Me.rtb1)
        Me.Controls.Add(Me.pic1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "spiro"
        Me.Text = "child"
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pic1 As PictureBox
    Friend WithEvents rtb1 As RichTextBox
    Friend WithEvents rtb2 As RichTextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents rtb3 As RichTextBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents pic2 As PictureBox
End Class
